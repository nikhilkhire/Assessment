package com.web.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.web.configuration.DataSourceConfiguration;
import com.web.model.Todo;

@Controller
public class HelloController {

	private static final Logger LOGGER = Logger.getLogger(HelloController.class.getName());
	@Autowired
    private DataSourceConfiguration dataSourceConfiguration;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String printWelcome(ModelMap model) {
		System.out.println("Hi");
		model.addAttribute("message", "Spring 3 MVC Hello World");
		return "UserManagement";

	}

		
	@RequestMapping(value = "/fetchAllTodo", method = RequestMethod.GET)
    public ResponseEntity<List<Todo>> helloWorld() {
        final DataSource dataSource = dataSourceConfiguration.dataSource();
        try {
            final Connection connection = dataSource.getConnection();
            final Statement statement = connection.createStatement();
            final ResultSet resultSet = statement.executeQuery("SELECT * FROM TODO");
            List<Todo> todos=new ArrayList<Todo>();
            while (resultSet.next()) {
                Todo todo=new Todo();
                todo.setStatus(resultSet.getString("STATUS"));
                todo.setTask(resultSet.getString("TASK"));
                todos.add(todo);
            }
            connection.close();
            System.out.println(todos.toString()+"========"+todos.size());
    		return new ResponseEntity<List<Todo>>(todos, HttpStatus.OK);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

	@RequestMapping(value = "/update/{task}", method = RequestMethod.PUT)
    public ResponseEntity<Todo> updateToDo(@PathVariable("task") String task) {
		
		System.out.println("Mark it as done "+task);
        final DataSource dataSource = dataSourceConfiguration.dataSource();
        try {
            final Connection connection = dataSource.getConnection();
            final Statement statement = connection.createStatement();
            String query=" UPDATE TODO SET STATUS = 'DONE' WHERE TASK='"+task+"'";
            final int count = statement.executeUpdate(query);
            connection.close();
            if(count>0){
        		return new ResponseEntity<Todo>(new Todo(), HttpStatus.OK);
            }
            else {
            	return new ResponseEntity<Todo>(new Todo(), HttpStatus.NOT_MODIFIED);	
			}
    		
        } catch (SQLException e) {
        	LOGGER.log(Level.SEVERE, "Exception occures in updateToDo "+e);
            
        }
        return new ResponseEntity<Todo>(new Todo(), HttpStatus.NOT_MODIFIED);
    }
	
	@RequestMapping(value = "/create", method = RequestMethod.POST)
    public ResponseEntity<Todo> createToDo(@RequestBody Todo todo) {
		String task=todo.getTask();
		System.out.println("Saving new task = "+task);
        final DataSource dataSource = dataSourceConfiguration.dataSource();
        try {
            final Connection connection = dataSource.getConnection();
            final Statement statement = connection.createStatement();
            String query="INSERT INTO TODO (TASK,STATUS) VALUES ('"+task+"','Pending')";
            final int count = statement.executeUpdate(query);
            connection.close();
            if(count>0){
        		return new ResponseEntity<Todo>(new Todo(), HttpStatus.OK);
            }
            else {
            	return new ResponseEntity<Todo>(new Todo(), HttpStatus.NOT_MODIFIED);	
			}
    		
        } catch (SQLException e) {
        	LOGGER.log(Level.SEVERE, "Exception occures in create to do "+e);
            
        }
        return new ResponseEntity<Todo>(new Todo(), HttpStatus.NOT_MODIFIED);
    }
	
	@RequestMapping(value = "/delete/{task}", method = RequestMethod.DELETE)
    public ResponseEntity<Todo> deleteToDo(@PathVariable("task") String task) {
		
		System.out.println("Mark it as done "+task);
        final DataSource dataSource = dataSourceConfiguration.dataSource();
        try {
            final Connection connection = dataSource.getConnection();
            final Statement statement = connection.createStatement();
            String query=" DELETE FROM TODO WHERE TASK='"+task+"'";
            final int count = statement.executeUpdate(query);
            connection.close();
            if(count>0){
        		return new ResponseEntity<Todo>(new Todo(), HttpStatus.OK);
            }
            else {
            	return new ResponseEntity<Todo>(new Todo(), HttpStatus.NOT_MODIFIED);	
			}
    		
        } catch (SQLException e) {
        	LOGGER.log(Level.SEVERE, "Exception occures in updateToDo "+e);
            
        }
        return new ResponseEntity<Todo>(new Todo(), HttpStatus.NOT_MODIFIED);
    }
}