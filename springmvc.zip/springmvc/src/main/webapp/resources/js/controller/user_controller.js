'use strict';

angular.module('myApp').controller('UserController', ['$scope', 'UserService', function($scope, UserService) {
    var self = this;
    self.todo={task:'',status:''};
    self.todos=[];

    self.submit = submit;
    self.remove = remove;
    self.reset = reset;
    self.markItAsDone=markItAsDone;
    
   fetchAllUsers();

    function fetchAllUsers(){
        UserService.fetchAllUsers()
            .then(
            function(d) {
                self.todos = d;
            },
            function(errResponse){
                console.error('Error while fetching Users');
            }
        );
    }

    function markItAsDone(task){
        console.log('task to be edited =', task);
    	UserService.markItAsDone(task)
        .then(
        		fetchAllUsers,
        function(errResponse){
            console.error('Error while marking as done');
        }
    );	
    }
    
    function createTodo(todo){
        UserService.createTodo(todo)
            .then(
            fetchAllUsers,
            function(errResponse){
                console.error('Error while creating todo');
            }
        );
    }

    function deleteTodo(task){
    	 console.log('task to be deleted =', task);
        UserService.deleteTodo(task)
            .then(
            fetchAllUsers,
            function(errResponse){
                console.error('Error while deleting todo');
            }
        );
    }

    function submit() {
            console.log('Saving New todo item', self.todo);
            createTodo(self.todo);
            reset();
    }

    function remove(task){
        console.log('task to be deleted', task);
        
        deleteTodo(task);
    }
    
    function reset(){
        self.todo={task:''};
        $scope.myForm.$setPristine(); //reset Form
    }

}]);
