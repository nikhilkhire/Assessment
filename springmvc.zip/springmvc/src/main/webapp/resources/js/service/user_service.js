'use strict';

angular.module('myApp').factory('UserService', ['$http', '$q', function($http, $q){


    var factory = {
        fetchAllUsers: fetchAllUsers,
        createTodo: createTodo,
        deleteTodo:deleteTodo,
        markItAsDone:markItAsDone
    };

    return factory;

    function fetchAllUsers() {
        var deferred = $q.defer();
        $http.get('http://localhost:8080/springmvc/fetchAllTodo')
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while fetching todos');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }	
    
    function markItAsDone(task) {
        var deferred = $q.defer();
        $http.put('http://localhost:8080/springmvc/update/'+task)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while fetching Users');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }

    function createTodo(todo) {
        var deferred = $q.defer();
        $http.post('http://localhost:8080/springmvc/create', todo)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while creating todo');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }


    
    function deleteTodo(task) {
        var deferred = $q.defer();
        $http.delete('http://localhost:8080/springmvc/delete/'+task)
            .then(
            function (response) {
                deferred.resolve(response.data);
            },
            function(errResponse){
                console.error('Error while deleting Todo');
                deferred.reject(errResponse);
            }
        );
        return deferred.promise;
    }

}]);
